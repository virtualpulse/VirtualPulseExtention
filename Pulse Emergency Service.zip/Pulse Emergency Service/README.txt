***Virtual Pulse Emergency Ambulance Service System***

1. Download the .zip file provided.
2. Extract the .zip file to a folder on your computer.
3. Open Google Chrome and go to 'chrome://extensions/'.
4. Enable "Developer mode" by toggling the switch at the top right of the Extensions page.
5. Click on "Load unpacked" and select the folder where extracted the extension files.
6. The extension will now be installed and ready to use.